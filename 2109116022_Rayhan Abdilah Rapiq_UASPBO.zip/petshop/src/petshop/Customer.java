/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package petshop;

import java.sql.*;


/**
 *
 * @author User
 */
public class Customer extends User{

    
    public String cariuserpass(String nama, String password){
        String query = "SELECT * FROM customer WHERE name = ? and password = ?";
        String has = "";
        try{
            java.sql.Connection conn = (Connection)Confdb.configDB();
            PreparedStatement pstmt = conn.prepareStatement(query);//cari ini user pass bisa!

            pstmt.setString(1, nama);//bisa 
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()){
                setId(rs.getInt("id_customer"));
                has = "bisa";
            }else{
                has = "salah";
            }
        }
        catch(Exception e){

        }
        return has;
    }

}
