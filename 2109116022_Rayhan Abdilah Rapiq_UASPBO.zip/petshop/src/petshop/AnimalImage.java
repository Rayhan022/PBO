/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package petshop;

import java.io.InputStream;

/**
 *
 * @author User
 */
interface AnimalImage {
    public abstract void Timage(InputStream img);
    public abstract void Timagepath(String pth);
}
