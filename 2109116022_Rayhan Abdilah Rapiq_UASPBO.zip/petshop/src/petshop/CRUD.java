/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package petshop;
import java.io.InputStream;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author User
 */
public class CRUD {
    public void create(String nama, String nohp, String kode){   //insert value custumer     
        String query = "INSERT INTO customer (name, phone , password )VALUES (? , ? , ?)";
        try{
            java.sql.Connection conn = (Connection)Confdb.configDB();
            PreparedStatement pstmt = conn.prepareStatement(query);

            pstmt.setString(1, nama); 
            pstmt.setString(2, nohp);
            pstmt.setString(3, kode);
            pstmt.execute();
        }
        catch (Exception e){
            
        }                
    }
    public String create(String nama,String tanggal,String kelamin,String ras,String vaksin,InputStream gambar,String path,String hewan,int harga){        
        String query = "INSERT INTO animaladp (name,birthDate,gender,breed,vaccine,image,imagePath,animalType,price)VALUES (?,?,?,?,?,?,?,?,?)";
        String has ="";
        try{
            java.sql.Connection conn = (Connection)Confdb.configDB();
            PreparedStatement pstmt = conn.prepareStatement(query);            
            pstmt.setString(1, nama);   
            pstmt.setString(2, tanggal);
            pstmt.setString(3, kelamin);   
            pstmt.setString(4, ras);   
            pstmt.setString(5, vaksin);   
            pstmt.setBlob(6, gambar);   
            pstmt.setString(7, path);  
            pstmt.setString(8, hewan);  
            pstmt.setInt(9, harga);
            int inserted = pstmt.executeUpdate();
            if(inserted > 0){
                has = "Sukses";
            }else{
                has = "Gagal";
            }
        }
        catch (Exception e){
            
        }      
        return has;
    }
    
    public void create(int AID,int UID){    
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
        java.util.Date date = new java.util.Date();  
        String dt =formatter.format(date); 

        String query1 = "INSERT INTO tb_animalsold (id_animalsold, name, animal_type , breed, gender, birthDate, vaccine , price ) select id_animaladp,name,animalType,breed,gender,birthDate,vaccine,price from animaladp where id_animaladp = "+AID;
        String query2 = "INSERT INTO tb_transaction (id_animalsold, id_customer, transaction_dt) values ("+AID+","+UID+","+"?)";
        try{
            java.sql.Connection conn = (Connection)Confdb.configDB();
            PreparedStatement pstmt1 = conn.prepareStatement(query1);
            PreparedStatement pstmt2 = conn.prepareStatement(query2);
            pstmt2.setString(1,dt);
            pstmt1.execute();
            pstmt2.execute();
            
        }
        catch (Exception e){            
        }
                
    }
        

    public String delete(int id){
        String query = "DELETE FROM animaladp WHERE id_animalAdp = "+id;
        String has="";
        try{
            java.sql.Connection conn = (Connection)Confdb.configDB();
            PreparedStatement pstmt = conn.prepareStatement(query);
            int inserted = pstmt.executeUpdate();
            if(inserted > 0){
                has = "Sukses";
            }else{
                has = "Gagal";
            }
        }
        catch (Exception e){
            
        }
        return has;

    }
    public String update(int id,String nama,String tanggal,String kelamin,String ras,String vaksin,String hewan,int harga){
        String query = "UPDATE animaladp SET name = ? ,birthDate = ? ,gender = ? ,breed = ? ,vaccine = ? ,animalType = ? ,price = ?  WHERE id_animalAdp = "+id;
        String has="";
        try{            
            java.sql.Connection conn = (Connection)Confdb.configDB();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, nama);   
            pstmt.setString(2, tanggal);
            pstmt.setString(3, kelamin);   
            pstmt.setString(4, ras);   
            pstmt.setString(5, vaksin);    
            pstmt.setString(6, hewan);  
            pstmt.setInt(7, harga);
            int inserted = pstmt.executeUpdate();
            if(inserted > 0){
                has = "Sukses";
            }else{
                has = "Gagal";
            }
        }
        catch (Exception e){
            
        } 
        return has;
    

    }
    public String update(int id,String nama,String tanggal,String kelamin,String ras,String vaksin,InputStream gambar,String path,String hewan,int harga){
        String query = "UPDATE animaladp SET name = ? ,birthDate = ? ,gender = ? ,breed = ? ,vaccine = ? ,image = ? ,imagePath = ? ,animalType = ? ,price = ?  WHERE id_animalAdp = "+id;
        String has="";
        try{            
            java.sql.Connection conn = (Connection)Confdb.configDB();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, nama);   
            pstmt.setString(2, tanggal);
            pstmt.setString(3, kelamin);   
            pstmt.setString(4, ras);   
            pstmt.setString(5, vaksin);   
            pstmt.setBlob(6, gambar);   
            pstmt.setString(7, path);  
            pstmt.setString(8, hewan);  
            pstmt.setInt(9, harga);
            int inserted = pstmt.executeUpdate();
            if(inserted > 0){
                has = "Sukses";
            }else{
                has = "Gagal";
            }
        }
        catch (Exception e){
            
        } 
        return has;
    
    }
    
    public String check(String nama){
        String query = "SELECT * FROM animaladp WHERE name = ? ";
        String has = "";
        try{
            java.sql.Connection conn = (Connection)Confdb.configDB();
            PreparedStatement pstmt = conn.prepareStatement(query);

            pstmt.setString(1,nama );
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()){
                has = "Tidak";

            }else{
                has = "Bisa";
            }
        }catch(Exception e){

        }
        return has;    
    }
           
    public String check(String nama,String nohp){
        String query = "SELECT * FROM customer WHERE name = ? OR phone = ?";
        String has = "";
        try{
            java.sql.Connection conn = (Connection)Confdb.configDB();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1,nama );
            pstmt.setString(2,nohp );
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()){
                has = "Tidak";

            }else{
                has = "Bisa";
            }
        }catch(Exception e){

        }
        return has;    
    }

}
