/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package petshop;

import java.io.InputStream;

/**
 *
 * @author User
 */

public class Animal implements Treatment,AnimalImage{
    public String name;
    public String birthDate;
    public String sex;
    public String breed;
    public String type;
    public String vaccine;
    public String path;
    public InputStream image;
    public int price;
    

    @Override
    public void Tvaccine(String vac){
        this.vaccine = vac;
    }
    
    public void instData(String nama,String tanggal,String kelamin,String ras,String vaksin,InputStream gambar,String path,String hewan,int harga){
        this.vaccine = vaksin;
        this.name = nama;
        this.image = gambar;
        this.path = path;
        this.type = hewan;
        this.sex = kelamin;
        this.breed = ras;
        this.birthDate = tanggal;
        this.price = harga;
    }
    public void instData(String tanggal,String kelamin,String ras,String vaksin,String path,int price){
        this.vaccine = vaksin;
        this.path = path;
        this.sex = kelamin;
        this.breed = ras;
        this.birthDate = tanggal;
        this.price = price;
    }
    public void instData(String nama,String tanggal,String kelamin,String ras,String vaksin,String tipe,int harga){
        this.vaccine = vaksin;
        this.name = nama;
        this.type = tipe;
        this.sex = kelamin;
        this.breed = ras;
        this.birthDate = tanggal;
        this.price = harga;
        
    }
    
    @Override
    public void Timage(InputStream img) {
        this.image = img;
    }

    @Override
    public void Timagepath(String pth) {
        this.path = pth;
    }

    public String getName() {
        return name;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public String getSex() {
        return sex;
    }

    public String getBreed() {
        return breed;
    }

    public String getType() {
        return type;
    }

    public String getVaccine() {
        return vaccine;
    }

    public String getPath() {
        return path;
    }

    public int getPrice() {
        return price;
    }

    public InputStream getImage() {
        return image;
    }
    
}
