/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gui;
import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import petshop.*;
import java.text.ParseException;
import java.util.Date;
/**
 *
 * @author User
 */
public class AdoptionAdmin extends javax.swing.JFrame {
    Integer AID=0;
    File f =null;
    String path = null;
    private ImageIcon format = null;
    ResultSet rs;
    CRUD crud = new CRUD();
    Animal hewan = new Animal();
    /**
     * Creates new form AdoptionAdmin
     */
    private void genderVac(){//c.getItem(c.getSelectedIndex())
        gender.add("Laki-laki");
        gender.add("Perempuan");
        vaccine.add("Belum");
        vaccine.add("Sudah");
        type.add("Kucing");
        type.add("Anjing");
    }
        private void clearColumn(){
        imagePath.setText(null);
        name.setText(null);
        breed.setText(null);
        labelImage.setIcon(null);
        price.setText(null);
        birthdate.setDate(null);
        vaccine.select("Belum");
        f = null;
    }

    private void displayData(){
        DefaultTableModel model = new DefaultTableModel(){
             @Override
            public boolean isCellEditable(int row, int column) {
       
            return false;
            }
        };
        model.addColumn("ID ");
        model.addColumn("Nama");
        model.addColumn("Jenis");
        model.addColumn("Harga");
    
        try{
            
            String sql = "SELECT * FROM animaladp";
            java.sql.Connection conn = (Connection)Confdb.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);
            
            while(res.next()){
                model.addRow(new Object[]{
                    res.getInt(1),
                    res.getString(2),
                    res.getString(3),
                    res.getInt(4)});
            }
            adopt.setModel(model);
            
        }catch(SQLException e){
            System.out.println("Eror : " + e.getMessage());
        }
    }
    
    public void loadImage(String pth){
        ImageIcon ii = new ImageIcon(pth);
        Image img = ii.getImage().getScaledInstance(labelImage.getWidth(), labelImage.getHeight(), Image.SCALE_SMOOTH);
        labelImage.setIcon(new ImageIcon(img));

    }
    public void loadImage(){
        try {
            byte[] imagedata = rs.getBytes("image");
            format = new ImageIcon(imagedata);           
            Image mm = format.getImage();
            Image img = mm.getScaledInstance(labelImage.getWidth(), labelImage.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon image = new ImageIcon(img);
            labelImage.setIcon(image);
        } catch (SQLException ex) {
            Logger.getLogger(AdoptionAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void read(int no){
        String query = "SELECT birthDate,gender,breed,vaccine,imagePath,price from animalAdp where id_animalAdp = "+no;
        java.sql.Connection conn;
        try {
            conn = (Connection)Confdb.configDB();
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()){
               hewan.instData(rs.getString("birthDate"),rs.getString("gender"),rs.getString("breed"),rs.getString("vaccine"),rs.getString("imagePath"),rs.getInt("price"));
            }else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(CRUD.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public void read(){
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String tgl = hewan.getBirthDate();
        try {
            Date date = formatter.parse(tgl);
            birthdate.setDate(date);
        } catch (ParseException ex) {
            Logger.getLogger(AdoptionAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }
        java.sql.Connection conn;
        try {
            conn = (Connection)Confdb.configDB();
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM animalAdp where id_animalAdp = ?");
            pstmt.setInt(1, AID);
            rs = pstmt.executeQuery();
            if(rs.next()){
               loadImage();
            }else{

            }
        } catch (SQLException ex) {
            Logger.getLogger(CRUD.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    public AdoptionAdmin() {
        initComponents();
        genderVac();
        displayData();
        clearColumn();
        
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        name = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        labelImage = new javax.swing.JLabel();
        save = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        update = new javax.swing.JButton();
        browse = new javax.swing.JButton();
        breed = new javax.swing.JTextField();
        birthdate = new com.toedter.calendar.JDateChooser();
        vaccine = new java.awt.Choice();
        gender = new java.awt.Choice();
        type = new java.awt.Choice();
        imagePath = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        adopt = new javax.swing.JTable();
        price = new javax.swing.JTextField();
        newcolumn = new javax.swing.JButton();
        exitback = new javax.swing.JButton();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1023, 643));
        setSize(new java.awt.Dimension(1023, 643));
        getContentPane().setLayout(null);

        name.setFont(new java.awt.Font("Century Schoolbook", 0, 13)); // NOI18N
        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });
        name.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nameKeyPressed(evt);
            }
        });
        getContentPane().add(name);
        name.setBounds(210, 60, 280, 30);
        name.setTransferHandler(null);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nama Hewan");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(60, 65, 100, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Ras Hewan");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(60, 105, 100, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Jenis Hewan");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(60, 145, 90, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Kelamin Hewan");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(60, 195, 110, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Tanggal Lahir");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(60, 245, 100, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Vaksin Hewan");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(60, 295, 110, 20);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Harga");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(60, 345, 60, 20);

        labelImage.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().add(labelImage);
        labelImage.setBounds(540, 40, 440, 260);

        save.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        save.setText("Tambah");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        getContentPane().add(save);
        save.setBounds(120, 490, 90, 30);

        delete.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        delete.setText("Hapus");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        getContentPane().add(delete);
        delete.setBounds(330, 490, 80, 30);

        update.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        update.setText("Ubah");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });
        getContentPane().add(update);
        update.setBounds(230, 490, 80, 30);

        browse.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        browse.setText("Cari Foto");
        browse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                browseActionPerformed(evt);
            }
        });
        getContentPane().add(browse);
        browse.setBounds(60, 380, 100, 30);

        breed.setFont(new java.awt.Font("Century Schoolbook", 0, 13)); // NOI18N
        breed.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                breedKeyPressed(evt);
            }
        });
        getContentPane().add(breed);
        breed.setBounds(210, 100, 280, 30);
        breed.setTransferHandler(null);
        getContentPane().add(birthdate);
        birthdate.setBounds(210, 240, 280, 30);

        vaccine.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        vaccine.setName(""); // NOI18N
        getContentPane().add(vaccine);
        vaccine.setBounds(210, 290, 280, 30);

        gender.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        getContentPane().add(gender);
        gender.setBounds(210, 190, 280, 30);

        type.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        getContentPane().add(type);
        type.setBounds(210, 140, 280, 30);

        imagePath.setFont(new java.awt.Font("Century Schoolbook", 0, 13)); // NOI18N
        getContentPane().add(imagePath);
        imagePath.setBounds(210, 380, 280, 30);
        imagePath.setEditable(false);

        adopt.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        // property value not set
        adopt.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        )
    );
    adopt.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            adoptMouseClicked(evt);
        }
    });
    jScrollPane1.setViewportView(adopt);

    getContentPane().add(jScrollPane1);
    jScrollPane1.setBounds(540, 340, 440, 260);

    price.setFont(new java.awt.Font("Century Schoolbook", 0, 13)); // NOI18N
    price.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            priceKeyTyped(evt);
        }
    });
    getContentPane().add(price);
    price.setBounds(210, 340, 280, 30);
    price.setTransferHandler(null);

    newcolumn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
    newcolumn.setText("Bersihkan");
    newcolumn.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            newcolumnActionPerformed(evt);
        }
    });
    getContentPane().add(newcolumn);
    newcolumn.setBounds(150, 540, 100, 30);

    exitback.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
    exitback.setText("Keluar");
    exitback.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            exitbackActionPerformed(evt);
        }
    });
    getContentPane().add(exitback);
    exitback.setBounds(300, 540, 80, 30);

    background.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
    background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/background/AdoptionAdmin.png"))); // NOI18N
    getContentPane().add(background);
    background.setBounds(0, 0, 1023, 643);

    pack();
    }// </editor-fold>//GEN-END:initComponents

    private void browseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_browseActionPerformed
        // TODO add your handling code here:

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setAcceptAllFileFilterUsed(false);
        FileNameExtensionFilter fnwf = new FileNameExtensionFilter("PNG JPG AND JPEG","png","jpeg","jpg");
        fileChooser.addChoosableFileFilter(fnwf);
        int load = fileChooser.showOpenDialog(null);
        
        if(load==fileChooser.APPROVE_OPTION){
            f = fileChooser.getSelectedFile();
            path = f.getAbsolutePath();
            imagePath.setText(path);
            loadImage(path);
        }
    }//GEN-LAST:event_browseActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        // TODO add your handling code here:

        String frmtTanggal ="yyyy-MM-dd";
        String check_tgl = String.valueOf(birthdate.getDate());
                
        String nama = name.getText();
        String kelamin = gender.getSelectedItem();
        String ras = breed.getText();
        String vaksin = vaccine.getSelectedItem();
        String tipe = type.getSelectedItem();
        String hargatx = price.getText();//s.substring(0,1)   
        String hargaidx0 = hargatx.substring(0,1);
        Integer harga = Integer.valueOf(hargatx);
        if(nama.isEmpty()|| f == null || ras.isEmpty()|| check_tgl.equals("null") || hargaidx0.equals("0")){
            JOptionPane.showMessageDialog(null,"Tolong isi yang benar");
        }else if(harga <100000){
            JOptionPane.showMessageDialog(null,"Terlalu murah");
        }
        else{
            try {
                SimpleDateFormat fm = new SimpleDateFormat(frmtTanggal);
                String tanggal = String.valueOf(fm.format(birthdate.getDate()));

                if(crud.check(nama).equals("Bisa")&& f != null){
                    InputStream is = new FileInputStream(f);
                    hewan.instData(nama, tanggal, kelamin, ras, vaksin, is, path, tipe,harga);

                    if(crud.create(hewan.getName(),hewan.getBirthDate(), hewan.getSex(), hewan.getBreed(), hewan.getVaccine(), hewan.getImage(), hewan.getPath(), tipe,hewan.getPrice()).equals("Sukses") ){
                        JOptionPane.showMessageDialog(null,"Sukses");
                    }else{
                        JOptionPane.showMessageDialog(null,"Gagal");
                    }
                }else{
                    JOptionPane.showMessageDialog(null,"Nama sudah pernah di input");

                }


            } catch (FileNotFoundException ex) {
                Logger.getLogger(AdoptionAdmin.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        displayData();
        clearColumn();

    }//GEN-LAST:event_saveActionPerformed

    private void newcolumnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newcolumnActionPerformed
        // TODO add your handling code here:
        clearColumn();
    }//GEN-LAST:event_newcolumnActionPerformed

    private void adoptMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adoptMouseClicked
        // TODO add your handling code here:
        int baris = adopt.rowAtPoint(evt.getPoint());
        int nomor = (int) adopt.getValueAt(baris, 0);
        AID = nomor;
        
      
        read(AID);
        read();
        String nama = adopt.getValueAt(baris, 1).toString();
        name.setText(nama);
        
        String tipe = adopt.getValueAt(baris, 2).toString();
        type.select(tipe);
        
        String harga = adopt.getValueAt(baris, 3).toString();
        price.setText(harga);
        
        gender.select(hewan.getSex());
        breed.setText(hewan.getBreed());
        vaccine.select(hewan.getVaccine());
        imagePath.setText(hewan.getPath());
                
        
        
        
    }//GEN-LAST:event_adoptMouseClicked

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        // TODO add your handling code here:
        if(crud.delete(AID).equals("Sukses")){
            JOptionPane.showMessageDialog(null,"Sukses");
        }else{
            JOptionPane.showMessageDialog(null,"Gagal");
        }
        displayData();
        clearColumn();
    }//GEN-LAST:event_deleteActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        // TODO add your handling code here:
        String frmtTanggal ="yyyy-MM-dd";
        String check_tgl = String.valueOf(birthdate.getDate());
        SimpleDateFormat fm = new SimpleDateFormat(frmtTanggal);
        String tanggal = String.valueOf(fm.format(birthdate.getDate()));
        String nama = name.getText();
        String kelamin = gender.getSelectedItem();
        String ras = breed.getText();
        String vaksin = vaccine.getSelectedItem();
        String tipe = type.getSelectedItem();
        String hargatx = price.getText();
        Integer harga = Integer.valueOf(hargatx);
        char hargaidx = hargatx.charAt(0);
        String hargaidx2 = Character.toString(hargaidx);

        try {
            if(nama.isEmpty()|| ras.isEmpty()|| check_tgl.equals("null") || hargaidx2.equals("0")){
                JOptionPane.showMessageDialog(null,"Tolong isi yang benar");
            }else if(harga <100000){
                JOptionPane.showMessageDialog(null,"Terlalu murah");
            }else{
                if(f ==null){
                    hewan.instData(nama,tanggal,kelamin,ras,vaksin,tipe,harga);
                    if(crud.update(AID,hewan.getName(),hewan.getBirthDate(), hewan.getSex(), hewan.getBreed(), hewan.getVaccine(), hewan.getType(),hewan.getPrice()).equals("Sukses") ){
                        JOptionPane.showMessageDialog(null,"Sukses");
                    }else{
                        JOptionPane.showMessageDialog(null,"Gagal");
                    }

                }else{
                    InputStream is = new FileInputStream(f);
                    hewan.instData(nama, tanggal, kelamin, ras, vaksin, is, path, tipe,harga);

                    if(crud.update(AID,hewan.getName(),hewan.getBirthDate(), hewan.getSex(), hewan.getBreed(), hewan.getVaccine(), hewan.getImage(), hewan.getPath(), hewan.getType(),hewan.getPrice()).equals("Sukses") ){
                        JOptionPane.showMessageDialog(null,"Sukses");
                    }else{
                        JOptionPane.showMessageDialog(null,"Gagal");
                    }
 
                }

            }
            
            
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(AdoptionAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }
        displayData();
        clearColumn();

    }//GEN-LAST:event_updateActionPerformed

    private void exitbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitbackActionPerformed
        // TODO add your handling code here:
        this.dispose();
        MenuAdmin menuadm = new MenuAdmin();
        menuadm.setVisible(true);
    }//GEN-LAST:event_exitbackActionPerformed

    private void priceKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_priceKeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if (!Character.isDigit(c)){
            evt.consume();
        }

    }//GEN-LAST:event_priceKeyTyped

    private void nameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nameKeyPressed
        // TODO add your handling code here:
        char str = evt.getKeyChar();
        if(Character.isLetter(str)||Character.isWhitespace(str)||Character.isISOControl(str)){
            name.setEditable(true);            
        }else{
            name.setEditable(false);            
        }

    }//GEN-LAST:event_nameKeyPressed

    private void breedKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_breedKeyPressed
        // TODO add your handling code here:
        char str = evt.getKeyChar();
        if(Character.isLetter(str)||Character.isWhitespace(str)||Character.isISOControl(str)){
            breed.setEditable(true);            
        }else{
            breed.setEditable(false);            
        }

    }//GEN-LAST:event_breedKeyPressed

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameActionPerformed
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdoptionAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdoptionAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdoptionAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdoptionAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdoptionAdmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable adopt;
    private javax.swing.JLabel background;
    private com.toedter.calendar.JDateChooser birthdate;
    private javax.swing.JTextField breed;
    private javax.swing.JButton browse;
    private javax.swing.JButton delete;
    private javax.swing.JButton exitback;
    private java.awt.Choice gender;
    private javax.swing.JTextField imagePath;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelImage;
    private javax.swing.JTextField name;
    private javax.swing.JButton newcolumn;
    private javax.swing.JTextField price;
    private javax.swing.JButton save;
    private java.awt.Choice type;
    private javax.swing.JButton update;
    private java.awt.Choice vaccine;
    // End of variables declaration//GEN-END:variables

    void setUID(int id_kost) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
